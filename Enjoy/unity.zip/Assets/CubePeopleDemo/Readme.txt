﻿Cube People Demo. (2021/4/25 - by Fatty War, id3644@gmail.com)

==This document explains how to use the pack.==

Introduction

	It is a cube character that goes well with hyper casual games.
	You can create moving characters using Mixamo.
	If this package fits your project well, see more characters and variations in the Pro version!
	Note) The demo package is also available for commercial use.

     Features:
	 -Character variation customization. (Head & upper body & lower body are separated by texture)
	 -Replace skin with texture. (UV mapped body)
	 -One texture covers both men and women
	 -Character setup to work with Mecanim.(No finger & toe bones/ holds fist)
	 -Supported with Mixamo.
	 -The character is 1M tall.(1M=1unit/unity)
	 -7x head, 55x upper body, 31x lower body Textures and more than +102 kinds of variations are prepared. (Full version only)

	
	
	Note).
	-The character is set with a humanoid mecanim. Characters can be animated using mixamo.com.
	-The demo package is also available for commercial use.



1. Two characters with 42 variations

	Meshes Folder
	Male and female combined model x1.
	3 kinds of accessories(hat, gun, rifle)

	Prefabs Folder
	0CP : Clean prefabs without scripts.
	Demo : The demo settings and scripts are attached, so please do not use it for purposes other than demos.

	Textures Folder
	3 types of lower body textures(underwear, pantsA, pantsB)
	3 types of upper body texture(underwear, topA, topB)
	7 types of female hair textures.(Auburn, Brown, Red, Blond, Purple , white, Blue)
	7 types of male hair textures(Auburn, Brown, Red, Blond, Black, white, bald)

2. Demo (Assets\CubePeopleDemo\Scenes\CubePeople_Demo)

	You can see the character variations contained in the package.
	In the scene, the "nav mesh agent" character moves around, and the player character can move using "WASD".



*If you have any questions or suggestions about the assets, please contact me.(id3644@gmail.com)
Thank you for your purchase.